// arm-linux-gnueabi-gcc armhf-ret2text.c -fno-stack-protector -o pwn
#include <stdio.h>
#include <stdlib.h>

void emmm(){
    system("/bin/sh");
}

int main(){
    setbuf(stdin, 0);
    setbuf(stdout, 0);
    setbuf(stderr, 0);
    char buf[0x50];
    puts("binLep is slacking off..\nPlease input something");
    read(0, buf, 0x70);
    puts("I have received your message, Thank you!");
    return 0;
}
